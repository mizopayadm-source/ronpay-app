/**
 * Date and Time utilities for RonPay adhering strictly to DD/MM/YYYY format.
 */

export const formatDateDDMMYYYY = (dateInput?: string | Date | number | null): string => {
  if (!dateInput) return '—';
  try {
    const d = typeof dateInput === 'object' && dateInput instanceof Date 
      ? dateInput 
      : new Date(dateInput);
    if (isNaN(d.getTime())) return String(dateInput);
    
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
  } catch {
    return String(dateInput);
  }
};

export const formatDateTimeDDMMYYYY = (dateInput?: string | Date | number | null): string => {
  if (!dateInput) return '—';
  try {
    const d = typeof dateInput === 'object' && dateInput instanceof Date 
      ? dateInput 
      : new Date(dateInput);
    if (isNaN(d.getTime())) return String(dateInput);
    
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    
    let hours = d.getHours();
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 should be 12
    const strHours = String(hours).padStart(2, '0');
    
    return `${day}/${month}/${year}, ${strHours}:${minutes} ${ampm}`;
  } catch {
    return String(dateInput);
  }
};

export const isCampaignExpired = (validityDate?: string, status?: string): boolean => {
  if (status === 'expired') return true;
  if (!validityDate) return false;
  try {
    const deadline = new Date(validityDate).getTime();
    const now = new Date().getTime();
    return now > deadline;
  } catch {
    return false;
  }
};
