import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  KeyRound, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  FileText, 
  Settings, 
  Sparkles, 
  Award, 
  AlertTriangle,
  Lock,
  Unlock,
  Trash2,
  Edit,
  Plus,
  RefreshCw,
  Search,
  ExternalLink,
  DollarSign,
  TrendingUp,
  Download,
  Building,
  Smartphone
} from 'lucide-react';
import { Campaign, CreatorProfile, Transaction, BawmCategory } from '../types';
import { formatDateDDMMYYYY } from '../utils/date';
import { BAWM_CONFIG } from '../data/initialData';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  campaigns: Campaign[];
  transactions: Transaction[];
  creators: CreatorProfile[];
  onUpdateCampaign: (campaign: Campaign) => void;
  onDeleteCampaign?: (campaignId: string) => void;
  onApproveCampaign: (campaign: Campaign) => void;
  onUpdateCreator: (creator: CreatorProfile) => void;
  onResetData: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  campaigns,
  transactions,
  creators,
  onUpdateCampaign,
  onDeleteCampaign,
  onApproveCampaign,
  onUpdateCreator,
  onResetData,
}) => {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [adminUserId, setAdminUserId] = useState<string>('admin');
  const [adminPassword, setAdminPassword] = useState<string>('ronpay2026');
  const [loginError, setLoginError] = useState<string>('');

  // Admin tabs: 'creators' | 'campaigns' | 'finances' | 'gateway'
  const [activeTab, setActiveTab] = useState<'creators' | 'campaigns' | 'finances' | 'gateway'>('creators');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Selected creator for editing/license
  const [editingCreator, setEditingCreator] = useState<CreatorProfile | null>(null);
  const [licenseDuration, setLicenseDuration] = useState<number>(365); // days

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      (adminUserId.trim().toLowerCase() === 'admin' || adminUserId.trim().toLowerCase() === 'admin@ronpay.mizoram.gov.in') &&
      (adminPassword === 'admin' || adminPassword === 'ronpay2026' || adminPassword === 'ronpay@admin2026')
    ) {
      setIsAuthenticated(true);
      setLoginError('');
    } else {
      setLoginError('User ID emaw Password a dik lo. (Default: admin / ronpay2026)');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAdminUserId('admin');
    setAdminPassword('');
  };

  // Financial Stats
  const totalVolume = transactions.reduce((acc, t) => acc + t.amount, 0);
  const totalPlatformFees = transactions.reduce((acc, t) => acc + (t.platformFee || Math.round(t.amount * 0.01)), 0);
  const onlineCount = transactions.filter(t => t.paymentMethod === 'online').length;
  const cashCount = transactions.filter(t => t.paymentMethod === 'cash').length;

  // Filtered Campaigns
  const filteredCampaigns = campaigns.filter(c => {
    if (selectedCategoryFilter !== 'all' && c.category !== selectedCategoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        c.title.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q) ||
        c.id.toLowerCase().includes(q) ||
        (c.mitthiHming && c.mitthiHming.toLowerCase().includes(q))
      );
    }
    return true;
  });

  // Grant License to Creator
  const handleGrantLicense = (creator: CreatorProfile, tier: 'basic' | 'pro' | 'apex') => {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + licenseDuration);

    const allCategories: BawmCategory[] = ['ralna', 'khawlsak', 'rikrum', 'kumtluang'];
    const updated: CreatorProfile = {
      ...creator,
      isApproved: true,
      isPhoneVerified: true,
      approvedCategories: tier === 'apex' ? allCategories : (tier === 'pro' ? ['ralna', 'khawlsak', 'rikrum'] : ['ralna', 'khawlsak']),
      trialExpiresAt: expiresAt.toISOString(),
    };

    onUpdateCreator(updated);
    alert(`✅ LICENSE GRANTED!\n\nCreator: ${creator.name} (${creator.orgName || 'Individual'})\nTier: ${tier.toUpperCase()}\nValidity: ${formatDateDDMMYYYY(expiresAt.toISOString())}`);
    setEditingCreator(null);
  };

  // Toggle Creator Category Permission
  const handleToggleCategory = (creator: CreatorProfile, cat: BawmCategory) => {
    const exists = creator.approvedCategories.includes(cat);
    const updatedApproved = exists
      ? creator.approvedCategories.filter(c => c !== cat)
      : [...creator.approvedCategories, cat];

    const updated: CreatorProfile = {
      ...creator,
      approvedCategories: updatedApproved,
    };
    onUpdateCreator(updated);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-fadeIn text-slate-800">
      <div className="bg-white w-full max-w-2xl rounded-3xl p-5 shadow-2xl border border-indigo-200 relative flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex justify-between items-center pb-3 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-slate-900 text-amber-400 flex items-center justify-center font-black shadow-md border border-slate-800">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900">RonPay Admin Dashboard</h3>
                <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-300 font-extrabold px-2 py-0.5 rounded-full">
                  Super Admin
                </span>
              </div>
              <p className="text-[10.5px] text-slate-400 font-medium">
                System control, Creator licensing, Campaign moderation & Fee ledger
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 hover:text-slate-700 hover:bg-slate-200 flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* LOGIN SCREEN IF NOT AUTHENTICATED */}
        {!isAuthenticated ? (
          <form onSubmit={handleLogin} className="p-6 space-y-4 max-w-md mx-auto w-full my-auto text-xs">
            <div className="text-center space-y-1.5 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-700 mx-auto flex items-center justify-center shadow-xs">
                <KeyRound className="w-6 h-6" />
              </div>
              <h4 className="text-base font-black text-slate-900">Admin Authentication Required</h4>
              <p className="text-[11px] text-slate-500">
                Admin User ID leh Password hmangin login rawh le.
              </p>
            </div>

            {loginError && (
              <div className="bg-rose-50 border border-rose-200 text-rose-700 p-2.5 rounded-xl text-xs font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10.5px] font-bold text-slate-700 block">Admin User ID *</label>
              <input
                type="text"
                required
                value={adminUserId}
                onChange={(e) => setAdminUserId(e.target.value)}
                placeholder="e.g. admin"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 text-xs focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10.5px] font-bold text-slate-700 block">Admin Password *</label>
              <input
                type="password"
                required
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter admin password"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 text-xs focus:outline-none focus:bg-white focus:border-indigo-600"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-amber-400 font-black py-3 rounded-xl transition cursor-pointer shadow-md text-xs flex items-center justify-center gap-2 mt-2"
            >
              <Lock className="w-4 h-4" />
              <span>Login to Admin Control Panel</span>
            </button>

            <p className="text-[10px] text-center text-slate-400 pt-2">
              Default Credentials: <b>admin</b> / <b>ronpay2026</b>
            </p>
          </form>
        ) : (
          /* AUTHENTICATED ADMIN DASHBOARD BODY */
          <div className="flex flex-col flex-1 overflow-hidden space-y-3 pt-2">
            {/* Top Stat Pills & Navigation Bar */}
            <div className="flex justify-between items-center gap-2 border-b border-slate-200 pb-2.5 overflow-x-auto text-xs shrink-0">
              <div className="flex gap-1.5">
                {[
                  { key: 'creators', label: `Creators & Licenses (${creators.length})`, icon: Users },
                  { key: 'campaigns', label: `Campaigns (${campaigns.length})`, icon: FileText },
                  { key: 'finances', label: `Fee & Ledger (₹${(totalPlatformFees).toLocaleString('en-IN')})`, icon: DollarSign },
                  { key: 'gateway', label: 'PhonePe Gateway', icon: Settings },
                ].map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.key}
                      onClick={() => setActiveTab(tab.key as any)}
                      className={`px-3 py-1.5 rounded-xl font-black text-[11px] whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                        activeTab === tab.key
                          ? 'bg-slate-900 text-amber-300 shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={handleLogout}
                className="text-[10.5px] font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-lg border border-rose-200 transition cursor-pointer shrink-0"
              >
                Logout
              </button>
            </div>

            {/* TAB 1: CREATOR LICENSES & USER MANAGEMENT */}
            {activeTab === 'creators' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
                <div className="flex justify-between items-center bg-indigo-50/70 p-3 rounded-2xl border border-indigo-200">
                  <div>
                    <h4 className="font-black text-indigo-950 text-xs">Creator License & Role Verification</h4>
                    <p className="text-[10.5px] text-indigo-700 font-medium">
                      Bawm QR siam theihna tur license pek, phone verify, leh category control-na
                    </p>
                  </div>
                  <span className="text-xs font-black bg-indigo-600 text-white px-2.5 py-1 rounded-xl shadow-xs">
                    {creators.length} Registered
                  </span>
                </div>

                <div className="space-y-2.5">
                  {creators.map((c, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 hover:border-slate-300 space-y-2.5 transition"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-black text-slate-900 text-sm">{c.name || 'Unnamed Creator'}</span>
                            {c.isApproved ? (
                              <span className="text-[9.5px] font-black bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-300 flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5" /> Licensed Pro
                              </span>
                            ) : (
                              <span className="text-[9.5px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md border border-amber-300">
                                Pending Approval
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                            {c.designation || 'Member'} • <b className="text-slate-700">{c.orgName || 'Mizo Community Org'}</b>
                          </p>
                          <p className="text-[10.5px] text-slate-400 font-mono">
                            📞 {c.phone || '9862000000'} • License Expires: {c.trialExpiresAt ? formatDateDDMMYYYY(c.trialExpiresAt) : 'Permanent'}
                          </p>
                        </div>

                        {/* License Action Buttons */}
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => handleGrantLicense(c, 'pro')}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-2.5 py-1.5 rounded-xl text-[10.5px] transition cursor-pointer flex items-center gap-1 shadow-xs"
                          >
                            <Award className="w-3 h-3" /> Grant License
                          </button>
                        </div>
                      </div>

                      {/* Category Permissions Chips */}
                      <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between flex-wrap gap-2">
                        <span className="text-[10px] font-bold text-slate-500">Allowed Categories:</span>
                        <div className="flex gap-1.5 flex-wrap">
                          {(['ralna', 'khawlsak', 'rikrum', 'kumtluang'] as BawmCategory[]).map(cat => {
                            const isAllowed = c.approvedCategories?.includes(cat);
                            return (
                              <button
                                key={cat}
                                onClick={() => handleToggleCategory(c, cat)}
                                className={`text-[9.5px] font-bold px-2 py-0.5 rounded-lg border transition cursor-pointer uppercase ${
                                  isAllowed
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                    : 'bg-slate-100 text-slate-400 border-slate-200 line-through'
                                }`}
                              >
                                {cat}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 2: CAMPAIGNS & MODERATION */}
            {activeTab === 'campaigns' && (
              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 text-xs">
                {/* Search & Category Filter */}
                <div className="flex gap-2 mb-2">
                  <div className="relative flex-1">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search campaign, mitthi, location..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:border-indigo-500 focus:outline-none"
                    />
                  </div>

                  <select
                    value={selectedCategoryFilter}
                    onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-700 focus:outline-none"
                  >
                    <option value="all">All Bawms</option>
                    <option value="ralna">Ralna</option>
                    <option value="khawlsak">Khawlsak</option>
                    <option value="rikrum">Rikrum</option>
                    <option value="kumtluang">Kumtluang</option>
                  </select>
                </div>

                {filteredCampaigns.map((camp) => (
                  <div
                    key={camp.id}
                    className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-md bg-slate-900 text-white">
                            {camp.category}
                          </span>
                          <span className={`text-[9.5px] font-black px-2 py-0.5 rounded-md ${
                            camp.status === 'active' ? 'bg-emerald-100 text-emerald-800' :
                            camp.status === 'pending_approval' ? 'bg-amber-100 text-amber-800 animate-pulse' :
                            'bg-rose-100 text-rose-800'
                          }`}>
                            {camp.status.toUpperCase()}
                          </span>
                        </div>
                        <h4 className="font-black text-slate-900 text-xs mt-1">{camp.title}</h4>
                        <p className="text-[10.5px] text-slate-500">📍 {camp.location} • UPI: <b className="font-mono text-slate-700">{camp.upiId}</b></p>
                      </div>

                      <div className="text-right text-[10px] text-slate-400">
                        <span>Validity: <b className="text-slate-800">{formatDateDDMMYYYY(camp.validityDate)}</b></span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                      <span className="text-[10px] text-slate-400 font-mono">ID: {camp.id}</span>
                      <div className="flex gap-1.5">
                        {camp.status === 'pending_approval' && (
                          <button
                            onClick={() => onApproveCampaign(camp)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-3 py-1 rounded-xl text-[10.5px] transition cursor-pointer flex items-center gap-1 shadow-xs"
                          >
                            <CheckCircle2 className="w-3 h-3" /> Approve Now
                          </button>
                        )}
                        <button
                          onClick={() => {
                            const newStatus = camp.status === 'active' ? 'expired' : 'active';
                            onUpdateCampaign({ ...camp, status: newStatus });
                          }}
                          className={`font-bold px-2.5 py-1 rounded-xl text-[10px] transition cursor-pointer border ${
                            camp.status === 'active'
                              ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                              : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                          }`}
                        >
                          {camp.status === 'active' ? 'Mark Expired' : 'Reactivate'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* TAB 3: FEE & FINANCIAL LEDGER */}
            {activeTab === 'finances' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div className="bg-slate-900 text-white p-3 rounded-2xl">
                    <span className="text-[9.5px] text-slate-400 uppercase font-bold">Total Platform Volume</span>
                    <div className="text-lg font-black text-amber-400 mt-1">₹{totalVolume.toLocaleString('en-IN')}</div>
                  </div>
                  <div className="bg-emerald-950 text-white p-3 rounded-2xl border border-emerald-800">
                    <span className="text-[9.5px] text-emerald-300 uppercase font-bold">RonPay 1% TSP Fee</span>
                    <div className="text-lg font-black text-emerald-400 mt-1">₹{totalPlatformFees.toLocaleString('en-IN')}</div>
                  </div>
                  <div className="bg-slate-100 p-3 rounded-2xl border border-slate-200">
                    <span className="text-[9.5px] text-slate-500 uppercase font-bold">Online UPI Trxn</span>
                    <div className="text-lg font-black text-slate-900 mt-1">{onlineCount}</div>
                  </div>
                  <div className="bg-slate-100 p-3 rounded-2xl border border-slate-200">
                    <span className="text-[9.5px] text-slate-500 uppercase font-bold">Cash Recorded</span>
                    <div className="text-lg font-black text-slate-900 mt-1">{cashCount}</div>
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
                  <h4 className="font-black text-slate-900 text-xs flex items-center justify-between">
                    <span>Recent Transaction Audit Stream</span>
                    <span className="text-[10px] text-slate-400">{transactions.length} total entries</span>
                  </h4>
                  <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                    {transactions.slice(0, 15).map(tx => (
                      <div key={tx.id} className="bg-white p-2 rounded-xl border border-slate-200 flex justify-between items-center text-[10.5px]">
                        <div>
                          <b className="text-slate-900">{tx.donorName}</b> • {tx.campaignTitle}
                          <div className="text-[9.5px] text-slate-400">{formatDateDDMMYYYY(tx.timestamp)} • Hash: {tx.txHash.substring(0, 10)}...</div>
                        </div>
                        <div className="text-right">
                          <div className="font-black text-emerald-700">₹{tx.amount}</div>
                          <span className="text-[9px] text-slate-400">1% Fee: ₹{tx.platformFee || Math.round(tx.amount * 0.01)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: PHONEPE GATEWAY & SYSTEM */}
            {activeTab === 'gateway' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
                <div className="bg-slate-900 text-white p-4 rounded-2xl space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-black text-amber-400 text-xs">PhonePe TSP Gateway Status</span>
                    <span className="text-[9.5px] font-bold bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full">ACTIVE UAT</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[10.5px] text-slate-300 font-mono pt-1">
                    <div>Merchant ID: <b>TSPMIZOPAYUAT</b></div>
                    <div>Client Version: <b>v1 (PG V2)</b></div>
                    <div>Split Settlement: <b>99% Campaign / 1% RonPay</b></div>
                    <div>Webhooks: <b>Active (POST /api/phonepe/webhook)</b></div>
                  </div>
                </div>

                <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-2xl space-y-2 text-rose-900">
                  <h4 className="font-black text-xs flex items-center gap-1.5 text-rose-950">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> Danger Zone: Reset System Data
                  </h4>
                  <p className="text-[10.5px] text-rose-700">
                    He hian demo database leh transaction zawng zawng a tifai anga, initial template state-ah a dah let ang.
                  </p>
                  <button
                    onClick={onResetData}
                    className="bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 px-3 rounded-xl transition cursor-pointer text-xs"
                  >
                    Reset System Demo State
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
