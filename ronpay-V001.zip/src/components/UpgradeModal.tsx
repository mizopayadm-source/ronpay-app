import React, { useState } from 'react';
import { X, ShieldCheck, ArrowUpRight, Lock, CheckCircle2, FileText } from 'lucide-react';
import { BawmCategory, CreatorProfile } from '../types';
import { BAWM_CONFIG } from '../data/initialData';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  creatorProfile: CreatorProfile;
  onUpgradeApproved: (newCategory: BawmCategory) => void;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  creatorProfile,
  onUpgradeApproved,
}) => {
  const [selectedCat, setSelectedCat] = useState<BawmCategory | null>(null);
  const [authProofDoc, setAuthProofDoc] = useState<string>('');

  if (!isOpen) return null;

  const allCategories: { key: BawmCategory; name: string }[] = [
    { key: 'ralna', name: 'Ralna Bawm' },
    { key: 'khawlsak', name: 'Khawlsak Bawm' },
    { key: 'rikrum', name: 'Rikrum Bawm' },
    { key: 'kumtluang', name: 'Kumtluang Bawm' },
  ];

  const handleDocChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAuthProofDoc(e.target.files[0].name);
    }
  };

  const handleUpgradeSubmit = () => {
    if (!selectedCat) {
      alert('Khawngaihin Bawm category thlang rawh!');
      return;
    }

    if (creatorProfile.approvedCategories.includes(selectedCat)) {
      alert('He category hi i nei sa tawh e.');
      return;
    }

    onUpgradeApproved(selectedCat);
    alert(`🎉 Successfully upgraded! Added ${BAWM_CONFIG[selectedCat].name} to your Creator privileges.`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-xs rounded-3xl p-5 space-y-3.5 shadow-2xl border border-indigo-200 text-slate-800">
        <div className="flex justify-between items-center border-b border-slate-100 pb-2.5">
          <div className="flex items-center gap-1.5">
            <ArrowUpRight className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-black text-indigo-950 uppercase tracking-wide">
              Upgrade QR Menu
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-[10.5px] text-slate-500 font-medium">
          Bawm belh/upgrade duh ber thlang rawh:
        </p>

        <div className="space-y-2">
          {allCategories.map(cat => {
            const isApproved = creatorProfile.approvedCategories.includes(cat.key);
            const isChecked = selectedCat === cat.key;

            return (
              <label
                key={cat.key}
                className={`flex items-center gap-2.5 p-2.5 rounded-xl border transition ${
                  isApproved
                    ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed opacity-75'
                    : isChecked
                    ? 'bg-indigo-50 border-indigo-300 text-indigo-950 font-black'
                    : 'bg-slate-50 border-slate-200 text-slate-800 cursor-pointer hover:bg-slate-100 font-bold'
                }`}
              >
                <input
                  type="radio"
                  name="upgrade_cat"
                  value={cat.key}
                  disabled={isApproved}
                  checked={isChecked}
                  onChange={() => setSelectedCat(cat.key)}
                  className="accent-indigo-600"
                />
                <span className="text-[11px] flex-1">
                  {cat.name} {isApproved ? '(Nei sa / Hman lai)' : ''}
                </span>
                {isApproved && <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />}
              </label>
            );
          })}
        </div>

        {/* Auth Document Upload */}
        <div className="bg-indigo-50/60 p-3 rounded-xl border border-indigo-200 space-y-1.5 text-xs">
          <label className="text-[10px] font-extrabold text-indigo-950 uppercase tracking-wider block">
            Pawl / NGO Hriatpuina Doc Upload *
          </label>
          <input
            type="file"
            accept="image/*,.pdf"
            onChange={handleDocChange}
            className="block w-full text-[9.5px] text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:font-bold file:bg-indigo-600 file:text-white cursor-pointer"
          />
          {authProofDoc && (
            <p className="text-[9.5px] text-emerald-700 font-bold">
              ✓ Attached: {authProofDoc}
            </p>
          )}
          <p className="text-[9.5px] text-slate-500 italic">
            Bawm thar hawng tur hian Pawl/NGO recommendation letter upload tel a tha e.
          </p>
        </div>

        <div className="pt-1">
          <button
            onClick={handleUpgradeSubmit}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-xl text-xs shadow-md transition cursor-pointer"
          >
            Upgrade & Submit Doc
          </button>
        </div>
      </div>
    </div>
  );
};
