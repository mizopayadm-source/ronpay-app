import React, { useState, useEffect } from 'react';
import { 
  QrCode, 
  FileDown, 
  Bell, 
  MapPin, 
  Sparkles, 
  Monitor, 
  Smartphone,
  Loader2,
  History,
  RotateCw
} from 'lucide-react';
import { ScreenId } from '../types';
import { Language } from '../utils/translations';

interface HeaderProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  onOpenScanner: () => void;
  onOpenReports: () => void;
  isDesktopView: boolean;
  onToggleDesktopView: () => void;
  notificationCount: number;
  onOpenNotifications: () => void;
  language: Language;
  onToggleLanguage: (lang: Language) => void;
  onOpenHistory: () => void;
  onOpenAdmin?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onNavigate,
  onOpenScanner,
  onOpenReports,
  isDesktopView,
  onToggleDesktopView,
  notificationCount,
  onOpenNotifications,
  language,
  onToggleLanguage,
  onOpenHistory,
}) => {
  const [userLocation, setUserLocation] = useState<string>(() => {
    return localStorage.getItem('kut_app_user_location') || 'Aizawl, Mizoram';
  });
  const [isLocating, setIsLocating] = useState<boolean>(false);

  // Approximate nearest Mizoram district helper
  const getNearestDistrict = (lat: number, lng: number): string => {
    const districts = [
      { name: 'Aizawl, Mizoram', lat: 23.7271, lng: 92.7176 },
      { name: 'Lunglei, Mizoram', lat: 22.8872, lng: 92.7410 },
      { name: 'Champhai, Mizoram', lat: 23.4735, lng: 93.3283 },
      { name: 'Kolasib, Mizoram', lat: 24.2256, lng: 92.6782 },
      { name: 'Serchhip, Mizoram', lat: 23.3417, lng: 92.8504 },
      { name: 'Siaha, Mizoram', lat: 22.4897, lng: 92.9774 },
      { name: 'Lawngtlai, Mizoram', lat: 22.5278, lng: 92.8920 },
      { name: 'Mamit, Mizoram', lat: 23.9268, lng: 92.4905 },
      { name: 'Saitual, Mizoram', lat: 23.9700, lng: 92.5700 },
      { name: 'Khawzawl, Mizoram', lat: 23.5350, lng: 93.1850 },
      { name: 'Hnahthial, Mizoram', lat: 22.9650, lng: 92.9300 },
    ];

    let closest = districts[0].name;
    let minDistance = Infinity;

    for (const d of districts) {
      const dist = Math.hypot(lat - d.lat, lng - d.lng);
      if (dist < minDistance) {
        minDistance = dist;
        closest = d.name;
      }
    }

    return closest;
  };

  // Reverse Geocode or Fallback to District
  const resolveLocationName = async (lat: number, lng: number) => {
    const isWithinMizoram = lat >= 21.8 && lat <= 24.6 && lng >= 92.1 && lng <= 93.6;
    const nearestDist = getNearestDistrict(lat, lng);

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14`, {
        signal: controller.signal,
        headers: { 'Accept-Language': 'en' }
      });
      clearTimeout(timeoutId);
      if (res.ok) {
        const data = await res.json();
        const addr = data.address || {};
        const state = addr.state;
        const localArea = addr.suburb || addr.neighbourhood || addr.village || addr.town || addr.city_district || addr.hamlet;
        const mainCity = addr.city || addr.town || addr.county;

        if (state === 'Mizoram' || isWithinMizoram) {
          if (localArea && mainCity) {
            const resolved = `${localArea}, ${mainCity}`;
            setUserLocation(resolved);
            localStorage.setItem('kut_app_user_location', resolved);
            return;
          } else if (mainCity) {
            const resolved = `${mainCity}, Mizoram`;
            setUserLocation(resolved);
            localStorage.setItem('kut_app_user_location', resolved);
            return;
          }
        }
      }
    } catch (e) {
      // Fallback on network timeout
    }

    const defaultMizoramLoc = nearestDist || 'Aizawl, Mizoram';
    setUserLocation(defaultMizoramLoc);
    localStorage.setItem('kut_app_user_location', defaultMizoramLoc);
  };

  const triggerLiveGPS = () => {
    if (navigator.geolocation) {
      setIsLocating(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          resolveLocationName(lat, lng).finally(() => setIsLocating(false));
        },
        () => {
          setUserLocation('Aizawl, Mizoram');
          setIsLocating(false);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    }
  };

  useEffect(() => {
    const saved = localStorage.getItem('kut_app_user_location');
    if (!saved) {
      triggerLiveGPS();
    }
  }, []);

  return (
    <header className="bg-slate-950 text-white shadow-xl relative shrink-0 border-b border-slate-800/80 sticky top-0 z-30">
      {/* Subtle glowing ambient lighting */}
      <div className="absolute -right-6 -top-6 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute left-1/4 -bottom-6 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="px-3 sm:px-4 py-2.5 sm:py-3 flex items-center justify-between gap-2 relative z-10">
        {/* Left Side: Brand Logo & Title & Location */}
        <button 
          onClick={() => onNavigate('screen-home')}
          className="flex items-center gap-2.5 text-left group transition cursor-pointer min-w-0 shrink"
        >
          {/* Logo Squircle */}
          <div className="relative shrink-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl p-0.5 bg-gradient-to-br from-amber-400 via-indigo-500 to-indigo-700 shadow-sm group-hover:scale-105 transition-transform duration-200">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center relative overflow-hidden">
                <svg viewBox="0 0 40 40" className="w-5 h-5 sm:w-5.5 sm:h-5.5 relative z-10" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="rPayGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FDE047" />
                      <stop offset="45%" stopColor="#F59E0B" />
                      <stop offset="100%" stopColor="#FB7185" />
                    </linearGradient>
                    <linearGradient id="rPayGrad2" x1="0%" y1="100%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#38BDF8" />
                      <stop offset="100%" stopColor="#818CF8" />
                    </linearGradient>
                  </defs>
                  <circle cx="20" cy="20" r="17" stroke="url(#rPayGrad2)" strokeWidth="1.5" strokeDasharray="4 2" strokeOpacity="0.4" />
                  <rect x="10" y="9" width="4.5" height="22" rx="2.25" fill="url(#rPayGrad)" />
                  <path 
                    d="M13 9H22C25.5 9 28.5 12 28.5 15.5C28.5 19 25.5 22 22 22H13" 
                    stroke="url(#rPayGrad)" 
                    strokeWidth="4.5" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                  />
                  <path 
                    d="M19 20L27 31" 
                    stroke="url(#rPayGrad)" 
                    strokeWidth="4.5" 
                    strokeLinecap="round" 
                  />
                  <circle cx="29" cy="11" r="2.2" fill="#38BDF8" />
                </svg>
              </div>
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-slate-950 shadow-xs" />
          </div>

          {/* Text Information */}
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 leading-none">
              <span className="font-black text-base sm:text-lg tracking-tight text-white font-sans">
                RON<span className="text-amber-400">PAY</span>
              </span>
              <span className="hidden sm:inline-flex bg-amber-400/15 text-amber-300 text-[8px] font-black px-1.5 py-0.5 rounded border border-amber-400/40 tracking-wider uppercase items-center gap-0.5 shrink-0">
                <Sparkles className="w-2 h-2 text-amber-300" /> MIZORAM
              </span>
            </div>

            {/* GPS Location Row */}
            <div 
              onClick={(e) => {
                e.stopPropagation();
                triggerLiveGPS();
              }}
              className="text-[10px] text-slate-400 font-medium flex items-center gap-1 hover:text-amber-300 transition cursor-pointer mt-1 truncate group"
              title="Click to refresh Live GPS Auto-Detection"
            >
              {isLocating ? (
                <Loader2 className="w-2.5 h-2.5 text-amber-400 animate-spin shrink-0" />
              ) : (
                <MapPin className="w-2.5 h-2.5 text-emerald-400 shrink-0 group-hover:scale-110 transition-transform" />
              )}
              <span className="truncate max-w-[105px] xs:max-w-[130px] sm:max-w-[180px] font-semibold text-slate-300">
                {userLocation}
              </span>
              <RotateCw className="w-2 h-2 text-slate-500 opacity-60 group-hover:opacity-100 group-hover:rotate-180 transition-all shrink-0" />
            </div>
          </div>
        </button>

        {/* Right Side: Clean Action Toolbar */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Language Switcher (MZ | EN) */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 text-[10px] font-black shadow-inner">
            <button
              onClick={() => onToggleLanguage('mizo')}
              className={`px-1.5 sm:px-2 py-1 rounded-lg transition cursor-pointer ${
                language === 'mizo'
                  ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Mizo version"
            >
              MZ
            </button>
            <button
              onClick={() => onToggleLanguage('english')}
              className={`px-1.5 sm:px-2 py-1 rounded-lg transition cursor-pointer ${
                language === 'english'
                  ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="English version"
            >
              EN
            </button>
          </div>

          {/* Sulhnu / History Button */}
          <button
            onClick={onOpenHistory}
            title={language === 'mizo' ? 'Pekna Sulhnu (History)' : 'Transaction History'}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-amber-400 flex items-center justify-center transition cursor-pointer active:scale-95 shrink-0"
          >
            <History className="w-3.5 h-3.5" />
          </button>

          {/* Reports Button (Visible on sm+ screens) */}
          <button
            onClick={onOpenReports}
            title="Reports & Export"
            className="hidden sm:flex w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-emerald-400 items-center justify-center transition cursor-pointer active:scale-95 shrink-0"
          >
            <FileDown className="w-3.5 h-3.5 text-emerald-400" />
          </button>

          {/* Desktop/Phone View Toggle (Visible on sm+ screens) */}
          <button
            onClick={onToggleDesktopView}
            title={isDesktopView ? "Switch to Phone Frame" : "Switch to Wide Desktop View"}
            className="hidden md:flex w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-amber-300 items-center justify-center transition cursor-pointer active:scale-95 shrink-0"
          >
            {isDesktopView ? <Smartphone className="w-3.5 h-3.5 text-amber-300" /> : <Monitor className="w-3.5 h-3.5 text-indigo-300" />}
          </button>

          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            title="Notifications"
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center transition relative cursor-pointer active:scale-95 shrink-0"
          >
            <Bell className="w-3.5 h-3.5" />
            {notificationCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-rose-500 rounded-full ring-1 ring-slate-950 animate-pulse" />
            )}
          </button>

          {/* QR Scanner Primary Action Button */}
          <button
            onClick={onOpenScanner}
            title="Scan QR Code"
            className="h-8 px-2.5 sm:px-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 rounded-xl flex items-center justify-center gap-1 font-black text-xs transition shadow-sm cursor-pointer transform active:scale-95 border border-amber-300 shrink-0"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span className="text-[10.5px] font-black tracking-tight hidden sm:inline">SCAN</span>
          </button>
        </div>
      </div>
    </header>
  );
};
